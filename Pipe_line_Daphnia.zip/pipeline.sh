#### check quality raw fastq files ###########

#Get data

for a in `cat list_dp.txt`; do fastq-dump -I --gzip --split-files $a; done 

#Trimming

myfunc() {
	bbtools=/data/proj/Daphnia_Pulex/bbtools/
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc/
	file=$1

	#Remove duplicates
	$bbtools/clumpify.sh -Xmx40g in=$fastq_dir/$file"_1.fastq.gz" \
								in2=$fastq_dir/$file"_2.fastq.gz" \
								out=$clean_dir/$file"_1.dedup.fastq.gz" \
								out2=$clean_dir/$file"_2.dedup.fastq.gz" dedupe

	#Trim adapters
	$bbtools/bbduk.sh -Xmx40g in=$clean_dir/$file"_1.dedup.fastq.gz" \
							  in2=$clean_dir/$file"_2.dedup.fastq.gz" \
							  out=$clean_dir/$file"_1.trimadap.fastq.gz" \
							  out2=$clean_dir/$file"_2.trimadap.fastq.gz" \
							  ktrim=r k=23 mink=11 hdist=1 tbo tpe minlen=90 ref=$bbtools/resources/adapters.fa ftm=5 ordered

	#Remove synthetic artifacts, spike-ins and perform quality-trimming
	$bbtools/bbduk.sh -Xmx40g in=$clean_dir/$file"_1.trimadap.fastq.gz" \
							  in2=$clean_dir/$file"_2.trimadap.fastq.gz" \
							  out=$clean_dir/$file"_1.trimmed.fastq.gz" \
							  out2=$clean_dir/$file"_2.trimmed.fastq.gz" \
							  k=27 ref=$bbtools/resources/sequencing_artifacts.fa.gz,$bbtools/resources/phix174_ill.ref.fa.gz qtrim=rl trimq=10 maq=10 ordered
}

export -f myfunc
for a in `cat list_dp.txt`; do myfunc $a ; done 

#mapping

myfunc() {

	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	file=$1
	./bwa mem -M -t 10 $fastq_dir/FLTH01.fasta $clean_dir/$file"_1.trimmed.fastq.gz" $clean_dir/$file"_2.trimmed.fastq.gz" > $clean_dir/$file".mapped.sam"
}
export -f myfunc
for a in `cat list_dp.txt`; do myfunc $a ; done 

# Getting bam file

myfunc() {
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc/
	file=$1

	#Remove synthetic artifacts, spike-ins and perform quality-trimming
	./samtools  view -b $clean_dir/$file".mapped.sam" > $clean_dir/$file".mapped.bam"
	./samtools  sort $clean_dir/$file".mapped.bam" -o $clean_dir/$file".sorted.bam"
	./samtools  index $clean_dir/$file".sorted.bam" 
}

export -f myfunc
for a in `cat list_dp.txt`; do myfunc $a ; done 

#Post processing 



export LD_LIBRARY_PATH=/cluster/java/latest/jre/lib/amd64:/cluster/java/latest/jre/lib/amd64/server:/cluster/java/latest/jre/lib/amd64/xawt:/cluster/java/latest/lib:/cluster/boost-1_64_0/lib:/cluster/gsl-2.3/lib
export PATH=/cluster/gridengine/ge2011.11/bin/linux-x64:/cluster/openmpi/bin:/cluster/java/latest/bin:/cluster/software/bin:/sysinst/bin:/cluster/gridengine/ge2011.11/bin/linux-x64:/usr/lib64/qt-3.3/bin:/cluster/openmpi/bin:/cluster/java/latest/bin:/cluster/software/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin:/data/proj/teaching/NGS_course/bin/


ref=/data/proj/Daphnia_Pulex/FLTH01.fasta
samtools=/cluster/software/Fedora27-x86_64/samtools-1.7/bin/samtools
GATK="java -jar /data/proj/teaching/NGS_course/Softwares/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar"
AddOrReplaceReadGroups="java -jar /data/proj/teaching/NGS_course/bin/AddOrReplaceReadGroups.jar "
FixMateInformation="java -jar /data/proj/teaching/NGS_course/bin/FixMateInformation.jar"
MarkDuplicates="java -jar /data/proj/teaching/NGS_course/bin/MarkDuplicates.jar "

#Generate the fasta file index
#samtools faidx $ref/spenn.fasta
#Generate the sequence dictionary

myfunc() {
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	file=$1
    	$AddOrReplaceReadGroups I=$clean_dir/$file".sorted.bam" O=$clean_dir/"Daphnia_pulex".$file.readgroups.bam RGID=$file RGLB=$file RGPL=ILLUMINA RGPU=$file RGSM=$file
	#rm -rf $clean_dir/$file.sorted.bam
	#Fix mates
	$FixMateInformation I=$clean_dir/"Daphnia_pulex".$file.readgroups.bam O=$clean_dir/"Daphnia_pulex".$file.fixm.bam TMP_DIR=./temp
	#rm -rf $clean_dir/"Daphnia_pulex".$file.readgroups.bam
	#Mark duplicates
	$MarkDuplicates I=$clean_dir/"Daphnia_pulex".$file.fixm.bam O=$clean_dir/"Daphnia_pulex".$file.dedup.bam M=$clean_dir/"Daphnia_pulex".$file.metric.txt MAX_FILE_HANDLES_FOR_READ_ENDS_MAP=500 OPTICAL_DUPLICATE_PIXEL_DISTANCE=100 MAX_RECORDS_IN_RAM=5000000 VALIDATION_STRINGENCY=SILENT
	#rm -rf $clean_dir/"Daphnia_pulex".$file.fixm.bam
	# index BAM file
	$samtools index $clean_dir/"Daphnia_pulex".$file.dedup.bam
	#local realignment around indels
	$GATK -T RealignerTargetCreator -R $ref -I $clean_dir/"Daphnia_pulex".$file.dedup.bam -log $clean_dir/"Daphnia_pulex".$file.pair_intervals.log -o $clean_dir/"Daphnia_pulex".$file.intervals
	$GATK -T IndelRealigner -R $ref -I $clean_dir/"Daphnia_pulex".$file.dedup.bam -targetIntervals $clean_dir/"Daphnia_pulex".$file.intervals -log $clean_dir/"Daphnia_pulex".$file.realigned.log -o $clean_dir/"Daphnia_pulex".$file.realigned.bam
}
export -f myfunc
for a in `cat list_dp.txt`; do myfunc $a ; done 


#Creating VCF 

myfunc() {
	fastq_dir=/data/proj/Daphnia_Pulex/
	file=$1
./freebayes/bin/freebayes  -f FLTH01.fasta /data/proj/Daphnia_Pulex/clean_fastqc/Daphnia_pulex.$1.realigned.bam > /data/proj/Daphnia_Pulex/clean_fastqc/$1.vcf
}
export -f myfunc
for a in `cat list_dp.txt`; do myfunc $a ; done 

#Filtering 

myfunc() {
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	vcflib=/data/proj/teaching/NGS_course/bin/vcflib/bin/./vcffilter
	file=$1
#filt1

$vcftools --vcf $clean_dir/$file.vcf --max-missing 0.5 --minQ 30 --minDP 5 --recode --recode-INFO-all --out $filtering/$file.f1

#filt2
$vcflib -s -f "AB > 0.25 & AB < 0.75 | AB < 0.01" $filtering/$file.f1.recode.vcf > $filtering/$file.f2.vcf

#filt3
$vcflib -f "PAIRED > 0.05 & PAIREDR > 0.05 & PAIREDR / PAIRED < 1.75 & PAIREDR / PAIRED > 0.25 | PAIRED < 0.05 & PAIREDR < 0.05" -s $filtering/$file.f2.vcf > $filtering/$file.f3.vcf

#filt4
$vcflib -f "QUAL / DP > 0.25" $filtering/$file.f3.vcf > $filtering/$file.f4.vcf

#filt5
#step1. create a list of the depth of each locus
cut -f8 $filtering/$file.f4.vcf | grep -oe "DP=[0-9]*" | sed -s 's/DP=//g' > $file.f4.DEPTH
#step2. create a list of quality scores
awk '!/#/' $filtering/$file.f4.vcf | cut -f1,2,6 > $filtering/$file.f4.vcf.loci.qual
#step3. calculate the mean depth
meanDP=`awk '{ sum += $file; n++ } END { if (n > 0) print sum / n; }' $file.f4.DEPTH`
#step4. mean plus 3X the square of the mean
distDP=`python -c "print int($meanDP+3*($meanDP*0.5))"`
#step5. paste the depth and quality files together and find the loci above the cutoff that do not have quality scores 2 times the depth
paste $filtering/$file.f4.vcf.loci.qual $file.f4.DEPTH | awk -v x=$distDP '$4 > x' | awk '$3 < 2 * $4' > $filtering/$file.f4.lowQDloci
#step5. remove those sites and recalculate the depth across loci 
$vcftools --vcf $filtering/$file.f4.vcf --site-depth --exclude-positions $filtering/$file.f4.lowQDloci --out $filtering/$file.f4
#step6. cut output to only the depth scores
cut -f3 $filtering/$file.f4.ldepth > $filtering/$file.f4.site.depth
#step7. calculate the average depth by dividing the above file by the number of individuals (x=1)
awk '!/D/' $filtering/$file.f4.site.depth | awk -v x=1 '{print $1/x}' > $filtering/$file.meandepthpersite
## check the Depth histogram
R --slave -e 'pdf("'$file.'DPhist.pdf"); hist(read.table(file="/data/proj/Daphnia_Pulex/clean_fastqc/filtering/'$file'.meandepthpersite")[,1], xlim=c(0,300), breaks=100000); dev.off()'
#step8. combine both filters to produce another VCF file (remove all loci above a mean depth of 150 and loci that do not have quality scores 2 times the depth)
$vcftools --vcf $filtering/$file.f4.vcf --recode --recode-INFO-all --out $filtering/$file.f5 --max-meanDP 70 --exclude-positions $filtering/$file.f4.lowQDloci 

#filt6
$vcftools --vcf $filtering/$file.f5.recode.vcf --max-missing 1.0 --min-alleles 2 --max-alleles 2 --recode --recode-INFO-all --stdout | gzip -c > $filtering/$file.f6.filtered.vcf.gz
}
export -f myfunc
for a in `cat list_dp.txt`; do myfunc $a ; done 

myfunc() {
	filter=/data/proj/teaching/NGS_course/Softwares/bbmap/./filterbyname.sh 
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	vcflib=/data/proj/teaching/NGS_course/bin/vcflib/bin/./vcfallelicprimitives
	sca=$1
	ind=$2 
	gunzip $filtering/$ind.f6.filtered.vcf.gz
	$vcflib $filtering/$ind.f6.filtered.vcf > $filtering/$ind.f7.filtered.vcf
 	$vcftools --vcf $filtering/$ind.f7.filtered.vcf --chr 'ENA|'$1'|'$1'.1' --remove-indels --recode --recode-INFO-all --out $filtering/$1.$2.final
	gzip $filtering/$1.$2.final.recode.vcf
}
export -f myfunc
for a in `cat list_sca_dp.txt`; do for b in `cat list_dp.txt`; do myfunc $a $b ; done  ; done 


myfunc() {
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	sca=$1
	ind=$2

$vcftools --vcf $filtering/$1.$2.final.recode.vcf --remove-indels --recode-INFO-all --out $filtering/$1.$2.final.noind

}
export -f myfunc
for a in `cat list_sca_dp.txt`; do for b in `cat list_dp.txt`; do myfunc $a $b ; done  ; done 



# Create Multihetsepfile


myfunc() {
	bedtools=/data/proj/teaching/NGS_course/Softwares/bedtools2-master/bin/bedtools
	filter=/data/proj/teaching/NGS_course/Softwares/bbmap/./filterbyname.sh 
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	ind=$1
	$bedtools genomecov -bga -ibam $clean_dir/Daphnia_pulex.$ind.realigned.bam -g FLTH01.fasta | \
	awk '($4 > 5) && ($4 < 70 )' | $bedtools merge -i - | gzip -c > $filtering/$ind.mask.bed.gz
}
export -f myfunc
for b in `cat list_dp.txt`; do myfunc $b ; done

myfunc() {
	bedtools=/data/proj/teaching/NGS_course/Softwares/bedtools2-master/bin/bedtools
	filter=/data/proj/teaching/NGS_course/Softwares/bbmap/./filterbyname.sh 
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	sca=$1
	ind=$2 
	zgrep 'ENA|'$1'|'$1'.1' $filtering/$ind.mask.bed.gz > $filtering/$ind.$sca.mask.bed
	gzip $filtering/$ind.$sca.mask.bed
}
export -f myfunc
for a in `cat list_sca_dp.txt`; do for b in `cat list_dp.txt`; do myfunc $a $b ; done  ; done 

myfunc() {
	filter=/data/proj/teaching/NGS_course/Softwares/bbmap/./filterbyname.sh 
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	vcflib=/data/proj/teaching/NGS_course/bin/vcflib/bin/./vcffilter
	file=$1

	$filter in=FLTH01.fasta out=$1.filtered_FLTH01.fasta names='ENA\|'$1'\|'$1'.1' include=t

}
export -f myfunc
for a in `cat list_sca_dp.txt`; do myfunc $a ; done 

myfunc() {
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	vcflib=/data/proj/teaching/NGS_course/bin/vcflib/bin/./vcffilter
	file=$1

./bwa index $1.filtered_FLTH01.fasta
./splitfa $1.filtered_FLTH01.fasta 300 > $1.reads.fa
./bwa aln -R 2000000 -O 3 -E 3 -t 6 $1.filtered_FLTH01.fasta $1.reads.fa > $1.reads.sai
./bwa samse $1.filtered_FLTH01.fasta $1.reads.sai $1.reads.fa > $1.reads_map.sam
./gen_raw_mask.pl < $1.reads_map.sam > $1.rawMask_filtered_FLTH01.fasta
./gen_mask -l 300 -r 0.5 $1.rawMask_filtered_FLTH01.fasta > $1.mask_filtered_FLTH01.fasta
./apply_mask_s $1.mask_filtered_FLTH01.fasta $1.filtered_FLTH01.fasta > $1.filtered_FLTH01_masked.fa

sed -i 's/[actgn]/N/g' $1.filtered_FLTH01_masked.fa

python generate_masked_ranges.py $1.filtered_FLTH01_masked.fa > $1.scafold_masked.bed

}
export -f myfunc
for a in `cat list_sca_dp.txt`; do myfunc $a ; done 

myfunc() {
	bedtools=/data/proj/teaching/NGS_course/Softwares/bedtools2-master/bin/bedtools
	filter=/data/proj/teaching/NGS_course/Softwares/bbmap/./filterbyname.sh 
	fastq_dir=/data/proj/Daphnia_Pulex/
	clean_dir=/data/proj/Daphnia_Pulex/clean_fastqc
	vcftools=/data/proj/teaching/NGS_course/Softwares/vcftools-vcftools-2543f81/bin/./vcftools
	filtering=/data/proj/Daphnia_Pulex/clean_fastqc/filtering
	sca=$1
	ind=$2 
	./generate_multihetsep.py \
			--mask=$filtering/$ind.$sca.mask.bed.gz \
			--negative_mask=$sca.scafold_masked.bed.gz\
			$filtering/$sca.$ind.final.recode.vcf.gz > $filtering/$ind.$sca.multihetsep.txt
}
export -f myfunc
for a in `cat list_sca_dp.txt`; do for b in `cat list_dp.txt`; do myfunc $a $b ; done  ; done 

